import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Membaca data dari CSV
file_path = 'salary.csv'
df = pd.read_csv(file_path)

# Menentukan kolom yang akan digunakan
columns_to_use = ['Umur', 'Pengalaman Kerja']
X = df[columns_to_use]

# Normalisasi data menggunakan StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# input dari pengguna untuk jumlah cluster
jumlah_cluster = int(input("Masukkan banyak cluster: "))

# Menerapkan algoritma K-Means
kmeans = KMeans(n_clusters=jumlah_cluster, random_state=42)
df['Cluster'] = kmeans.fit_predict(X_scaled)

# Visualisasi hasil cluster
plt.figure(figsize=(8, 6))

# Menampilkan semua cluster
for cluster in range(jumlah_cluster):
    cluster_data = df[df['Cluster'] == cluster]
    plt.scatter(cluster_data['Umur'], cluster_data['Pengalaman Kerja'], label=f'Cluster {cluster}')

plt.title('Hasil K-Means Clustering')
plt.xlabel('Umur')
plt.ylabel('Pengalaman Kerja')
plt.legend()
plt.show()
