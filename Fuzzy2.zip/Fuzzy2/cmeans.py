import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import skfuzzy as fuzz

# Membaca data dari CSV
file_path = 'salary.csv'
df = pd.read_csv(file_path)

# Menentukan kolom yang akan digunakan
columns_to_use = ['Umur', 'Pengalaman Kerja']
X = df[columns_to_use]

# Normalisasi data menggunakan StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# input dari pengguna untuk jumlah cluster
jumlah_cluster = int(input("Masukkan banyak cluster: "))

# Menerapkan algoritma Fuzzy C-Means
cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(X_scaled.T, jumlah_cluster, 2, error=0.005, maxiter=1000, init=None)

# Mendapatkan indeks cluster dengan tingkat keanggotaan tertinggi untuk setiap data point
cluster_membership = pd.DataFrame(u.T, columns=[f'Cluster_{i+1}' for i in range(jumlah_cluster)])
df['Cluster'] = cluster_membership.idxmax(axis=1)

# Visualisasi hasil cluster menggunakan PCA untuk mengurangi dimensi
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

plt.figure(figsize=(8, 6))

# Menampilkan semua cluster
for cluster in cluster_membership.columns:
    cluster_data = df[df['Cluster'] == cluster]
    plt.scatter(cluster_data['Umur'], cluster_data['Pengalaman Kerja'], label=cluster)

plt.title('Hasil Fuzzy C-Means Clustering')
plt.xlabel('Umur')
plt.ylabel('Pengalaman Kerja')
plt.legend()
plt.show()
